"""Pure functions for expense splitting, balance computation, and debt simplification.

All currency values are handled with Decimal to avoid floating-point drift.
Rounding is always to 2 decimal places with ROUND_HALF_UP.
"""

from decimal import Decimal, ROUND_HALF_UP
from typing import Optional

CENT = Decimal("0.01")
TWO_PLACES = Decimal("0.01")


def _round(value: Decimal) -> Decimal:
    """Round a Decimal to 2 decimal places, HALF_UP."""
    return value.quantize(TWO_PLACES, rounding=ROUND_HALF_UP)


# ---------------------------------------------------------------------------
# M5 – Validation
# ---------------------------------------------------------------------------

def validate_expense(expense: dict) -> list[str]:
    """Return a (possibly empty) list of human-readable validation errors.

    Rules enforced:
      - ``payer`` must be a member.
      - ``amount`` must be > 0.
      - ``members`` must contain at least 1 entry.
      - When *split_type* is ``"exact"``, *exact_amounts* must sum to *amount*.
      - When *split_type* is ``"percentage"``, *percentages* must sum to 100.
    """
    errors: list[str] = []

    payer = expense.get("payer", "")
    amount = _safe_decimal(expense.get("amount"))
    members = expense.get("members", [])
    split_type = expense.get("split_type", "equal").lower()

    # -- payer is a member --
    if payer not in members:
        errors.append(f"Payer '{payer}' is not in the members list: {members}")

    # -- amount > 0 --
    if amount is None or amount <= 0:
        errors.append(f"Amount must be a positive number, got {expense.get('amount')!r}")
        # can't validate further without a valid amount
        return errors

    # -- at least one member --
    if not isinstance(members, list) or len(members) == 0:
        errors.append("Members list must contain at least one member")
        return errors

    # -- split-type specific checks --
    if split_type == "exact":
        exact_amounts = expense.get("exact_amounts", [])
        if len(exact_amounts) != len(members):
            errors.append(
                f"exact_amounts length ({len(exact_amounts)}) "
                f"must match members length ({len(members)})"
            )
        else:
            total = sum(_safe_decimal(a) or Decimal(0) for a in exact_amounts)
            if _round(total) != _round(amount):
                errors.append(
                    f"exact_amounts sum ({_round(total)}) must equal the expense amount ({_round(amount)})"
                )

    elif split_type == "percentage":
        percentages = expense.get("percentages", [])
        if len(percentages) != len(members):
            errors.append(
                f"percentages length ({len(percentages)}) "
                f"must match members length ({len(members)})"
            )
        else:
            total_pct = sum(_safe_decimal(p) or Decimal(0) for p in percentages)
            if _round(total_pct) != Decimal("100"):
                errors.append(
                    f"percentages sum ({_round(total_pct)}) must equal 100"
                )

    # -- detect negative amounts in exact_amounts --
    if split_type == "exact":
        for i, a in enumerate(expense.get("exact_amounts", [])):
            val = _safe_decimal(a)
            if val is not None and val < 0:
                errors.append(f"exact_amounts[{i}] is negative: {val}")

    return errors


# ---------------------------------------------------------------------------
# M1 – Split an individual expense into per-member shares
# ---------------------------------------------------------------------------

def split_expense(expense: dict) -> list[dict]:
    """Return each member's share for a single expense.

    Returns a list of ``{"member": str, "share": Decimal}`` dicts.
    The share is *what the member owes the payer* (or 0 for the payer
    themselves).
    """
    amount = _safe_decimal(expense["amount"])
    members = list(expense["members"])
    split_type = expense.get("split_type", "equal").lower()
    n = len(members)

    if n == 0:
        return []

    if split_type == "equal":
        share = _round(amount / n)
        return [{"member": m, "share": share} for m in members]

    if split_type == "exact":
        exact_amounts = [_safe_decimal(a) for a in expense.get("exact_amounts", [])]
        return [{"member": members[i], "share": _round(exact_amounts[i])} for i in range(n)]

    if split_type == "percentage":
        percentages = [_safe_decimal(p) for p in expense.get("percentages", [])]
        total = Decimal(0)
        shares = []
        for i in range(n):
            pct = percentages[i] if i < len(percentages) else Decimal(0)
            share = _round(amount * pct / Decimal("100"))
            shares.append({"member": members[i], "share": share})
            total += share
        # Adjust for rounding drift: add the residual to the *last non-payer*
        # so totals always match exactly.
        drift = _round(amount - total)
        if drift != 0 and n > 0:
            # Prefer adjusting a member who is NOT the payer if possible.
            payer = expense.get("payer", "")
            for i in range(n - 1, -1, -1):
                if shares[i]["member"] != payer:
                    shares[i]["share"] = _round(shares[i]["share"] + drift)
                    break
            else:
                shares[-1]["share"] = _round(shares[-1]["share"] + drift)
        return shares

    return []  # unknown split type


# ---------------------------------------------------------------------------
# M2 – Net balances for every member
# ---------------------------------------------------------------------------

def compute_balances(expenses: list[dict]) -> dict[str, Decimal]:
    """Compute each member's net balance from a list of expenses.

    *Positive*  → the member is owed money (net creditor).
    *Negative*  → the member owes money (net debtor).
    *Zero*      → settled.
    """
    balances: dict[str, Decimal] = {}

    for expense in expenses:
        payer = expense["payer"]
        if payer not in balances:
            balances[payer] = Decimal(0)

        shares = split_expense(expense)
        for entry in shares:
            member = entry["member"]
            share = entry["share"]
            if member not in balances:
                balances[member] = Decimal(0)

            # The person who paid gets credited with each share
            # (others owe the payer)
            balances[payer] += share
            # Each member owes their share
            balances[member] -= share

    # Round every balance to 2 dp and remove zeros if desired (keep for clarity)
    return {k: _round(v) for k, v in sorted(balances.items())}


# ---------------------------------------------------------------------------
# M3 – Debt simplification (minimum-cash-flow / greedy)
# ---------------------------------------------------------------------------

def simplify_debts(balances: dict[str, Decimal]) -> list[dict]:
    """Reduce net balances to the minimum number of "from pays to ₹X" settlements.

    Uses the greedy largest-creditor-meets-largest-debtor algorithm which
    yields a near-minimal (often optimal) number of transactions.

    Returns a list of ``{"from": str, "to": str, "amount": Decimal}`` dicts
    sorted by amount descending.
    """
    # Separate into creditors and debtors, ignoring zero balances.
    creditors: list[tuple[str, Decimal]] = []  # positive balance
    debtors: list[tuple[str, Decimal]] = []    # negative balance

    for person, bal in balances.items():
        if bal > 0:
            creditors.append((person, bal))
        elif bal < 0:
            debtors.append((person, abs(bal)))  # store as positive for easier math

    settlements: list[dict] = []

    # Greedy matching
    while creditors and debtors:
        # Sort by amount descending each iteration
        creditors.sort(key=lambda x: x[1], reverse=True)
        debtors.sort(key=lambda x: x[1], reverse=True)

        creditor_name, credit_amt = creditors[0]
        debtor_name, debt_amt = debtors[0]

        settle_amt = min(credit_amt, debt_amt)
        settlements.append({
            "from": debtor_name,
            "to": creditor_name,
            "amount": settle_amt,
        })

        # Reduce the matched amounts
        new_credit = _round(credit_amt - settle_amt)
        new_debt = _round(debt_amt - settle_amt)

        # Replace or remove the first entries
        if new_credit > 0:
            creditors[0] = (creditor_name, new_credit)
        else:
            creditors.pop(0)

        if new_debt > 0:
            debtors[0] = (debtor_name, new_debt)
        else:
            debtors.pop(0)

    # Sort settlements by amount descending for readability
    settlements.sort(key=lambda s: s["amount"], reverse=True)
    return settlements


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _safe_decimal(value) -> Optional[Decimal]:
    """Convert a value to Decimal, returning None on failure."""
    if value is None:
        return None
    try:
        return Decimal(str(value))
    except Exception:
        return None