"""Expense Splitter with Debt Simplification agent.

Usage::

    from agent import run
    result = run("Add these expenses and simplify the debts", expenses=...)
    print(result)
"""

from __future__ import annotations

import json
import re
from decimal import Decimal
from pathlib import Path
from typing import Any, Optional

from tools import compute_balances, simplify_debts, validate_expense

# ---------------------------------------------------------------------------
# Entry point required by the scaffold
# ---------------------------------------------------------------------------


def run(task: str, expenses: Optional[list[dict]] = None) -> dict:
    """Plan, execute, and return the result for the given natural-language task.

    Parameters
    ----------
    task : str
        Natural-language instruction, e.g. "add these expenses and simplify".
    expenses : list[dict] | None
        Expense objects (parsed from JSON or built programmatically).

    Returns
    -------
    dict with keys:
        - plan       (list[str])   — the steps the agent executed.
        - result     (dict | None) — computed output.
        - escalated  (bool)        — True when human review is needed.
    """
    plan: list[str] = []
    escalated = False

    # 1. Parse intent --------------------------------------------------------
    intents = _parse_intent(task)
    plan.append("parse_task")

    # 2. If no expenses supplied, try to load from file referenced in task ----
    if expenses is None:
        file_path = _extract_file_ref(task)
        if file_path is not None:
            expenses, load_err = _load_expenses_file(file_path)
            plan.append(f"load_file:{file_path}")
            if load_err:
                return {
                    "plan": plan,
                    "result": {"error": load_err},
                    "escalated": True,
                }

    if not expenses:
        return {
            "plan": plan,
            "result": {"error": "No expenses provided. Pass `expenses=` or mention a JSON file."},
            "escalated": False,
        }

    # 3. Validate -------------------------------------------------------------
    if "validate" in intents or "add" in intents or not intents:
        plan.append("validate_expenses")
        validation_errors: list[str] = []
        for idx, exp in enumerate(expenses):
            errs = validate_expense(exp)
            for e in errs:
                validation_errors.append(f"[expense {idx}] {e}")
        if validation_errors:
            return {
                "plan": plan,
                "result": {"validation_errors": validation_errors},
                "escalated": True,
            }

    # 4. Compute balances ----------------------------------------------------
    if "balance" in intents or "simplify" in intents or "add" in intents or not intents:
        plan.append("compute_balances")
        balances = compute_balances(expenses)

    # 5. Simplify debts -------------------------------------------------------
    if "simplify" in intents or not intents:
        plan.append("simplify_debts")
        settlements = simplify_debts(balances)

    # 6. Build result ---------------------------------------------------------
    result: dict[str, Any] = {
        "member_count": len(balances),
        "expense_count": len(expenses),
        "total_amount": str(
            sum(Decimal(str(e["amount"])) for e in expenses)
        ),
        "balances": {k: str(v) for k, v in balances.items()},
        "settlements": [
            {"from": s["from"], "to": s["to"], "amount": str(s["amount"])}
            for s in settlements
        ],
        "summary": _summary(settlements),
    }

    # 7. Edge-case flag: cycle detection --------------------------------------
    if _detect_cycle(settlements):
        result["note"] = "Cycle detected in settlements — already simplified."
        escalated = True

    return {"plan": plan, "result": result, "escalated": escalated}


# ---------------------------------------------------------------------------
# Private helpers
# ---------------------------------------------------------------------------


def _parse_intent(task: str) -> set[str]:
    """Extract intents from natural language."""
    lower = task.lower()
    intents: set[str] = set()
    if re.search(r"\bvalidate\b", lower):
        intents.add("validate")
    if re.search(r"\bbalance\b", lower):
        intents.add("balance")
    if re.search(r"\bsimplif|simplify|settl|settle|minimum.*transaction|min.*cash", lower):
        intents.add("simplify")
    if re.search(r"\badd\b", lower):
        intents.add("add")
    return intents


def _extract_file_ref(task: str) -> Optional[str]:
    """Try to extract a file path reference from the task string."""
    # Match quoted paths or bare *.json
    m = re.search(r"""["']?([\w./\\-]+\.json)["']?""", task)
    return m.group(1) if m else None


def _load_expenses_file(file_path: str) -> tuple[Optional[list[dict]], Optional[str]]:
    """Load and parse a JSON expenses file. Returns (data, error_message)."""
    path = Path(file_path)
    if not path.exists():
        return None, f"File not found: {file_path}"

    try:
        raw = path.read_text(encoding="utf-8")
    except OSError as exc:
        return None, f"Cannot read {file_path}: {exc}"

    try:
        data = json.loads(raw)
    except json.JSONDecodeError as exc:
        return None, f"Invalid JSON in {file_path}: {exc}"

    # Support both a single expense object and a list
    if isinstance(data, dict):
        return [data], None
    if isinstance(data, list):
        return data, None
    return None, f"Unexpected JSON structure in {file_path}: expected object or list"


def _summary(settlements: list[dict]) -> str:
    """One-line human-readable summary of the settlements."""
    if not settlements:
        return "All settled — no payments needed."
    parts = [
        f"{s['from']} → {s['to']} ₹{s['amount']}"
        for s in settlements
    ]
    return " | ".join(parts)


def _detect_cycle(settlements: list[dict]) -> bool:
    """Return True if the settlement graph has a cycle (A→B, B→A is simplest)."""
    edges: set[tuple[str, str]] = set()
    for s in settlements:
        pair = (s["from"], s["to"])
        reverse = (s["to"], s["from"])
        if reverse in edges:
            return True
        edges.add(pair)
    return False


# ---------------------------------------------------------------------------
# CLI convenience
# ---------------------------------------------------------------------------

if __name__ == "__main__":
    # Run with: python agent.py --task "Add and simplify" --file expenses.json
    import argparse

    parser = argparse.ArgumentParser(description="Expense Splitter Agent")
    parser.add_argument("--task", default="Add these expenses and simplify the debts")
    parser.add_argument("--file", help="Path to expenses.json")
    args = parser.parse_args()

    expenses = None
    if args.file:
        expenses, err = _load_expenses_file(args.file)
        if err:
            print(f"ERROR: {err}")
            raise SystemExit(1)

    output = run(args.task, expenses=expenses)
    print(json.dumps(output, indent=2, ensure_ascii=False))